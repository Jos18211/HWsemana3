<?php
 class RoutesController {
    public function index(){
        include "routes/routes.php";
    }
 }