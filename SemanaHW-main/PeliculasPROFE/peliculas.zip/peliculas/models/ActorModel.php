<?php
class ActorModel{
    public $enlace;
    public function __construct()
    {
        $this->enlace=new MySqlConnect();
    }
    /*Listar */
    public function all(){

    }
    /*Obtener */
    public function get($id){
        
    }
    /*Crear */
    public function create($objeto){
        
    }
    /*Actualizar */
    public function update($objeto){
        
    }
}